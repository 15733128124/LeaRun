//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ѧ���������ñ�������ݽ�����
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.26 10:20</date>
    /// </author>
    /// </summary>
    public class DStudent_TestSetBll : RepositoryFactory<DStudent_TestSet>
    {
    }
}