//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �������б�
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.26 10:12</date>
    /// </author>
    /// </summary>
    public class DBase_CitiesBll : RepositoryFactory<DBase_Cities>
    {
    }
}