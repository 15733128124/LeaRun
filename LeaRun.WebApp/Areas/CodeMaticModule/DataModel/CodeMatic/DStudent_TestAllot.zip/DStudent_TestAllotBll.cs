//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// DStudent_TestAllot
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.13 09:07</date>
    /// </author>
    /// </summary>
    public class DStudent_TestAllotBll : RepositoryFactory<DStudent_TestAllot>
    {
    }
}