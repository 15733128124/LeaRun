//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ѧ���ɼ����Ա�������ݽ�����
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.26 10:41</date>
    /// </author>
    /// </summary>
    public class DStudent_TestScoreBll : RepositoryFactory<DStudent_TestScore>
    {
    }
}