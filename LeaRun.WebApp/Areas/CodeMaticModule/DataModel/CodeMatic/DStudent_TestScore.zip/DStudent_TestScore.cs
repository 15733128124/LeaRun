//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// ѧ���ɼ����Ա�������ݽ�����
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.26 10:41</date>
    /// </author>
    /// </summary>
    [Description("ѧ���ɼ����Ա�������ݽ�����")]
    [PrimaryKey("ID")]
    public class DStudent_TestScore : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("ID")]
        public int? ID { get; set; }
        /// <summary>
        /// StudentCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("StudentCode")]
        public string StudentCode { get; set; }
        /// <summary>
        /// StudentName
        /// </summary>
        /// <returns></returns>
        [DisplayName("StudentName")]
        public string StudentName { get; set; }
        /// <summary>
        /// StudentSex
        /// </summary>
        /// <returns></returns>
        [DisplayName("StudentSex")]
        public string StudentSex { get; set; }
        /// <summary>
        /// Heigh
        /// </summary>
        /// <returns></returns>
        [DisplayName("Heigh")]
        public string Heigh { get; set; }
        /// <summary>
        /// Weight
        /// </summary>
        /// <returns></returns>
        [DisplayName("Weight")]
        public string Weight { get; set; }
        /// <summary>
        /// BMI
        /// </summary>
        /// <returns></returns>
        [DisplayName("BMI")]
        public string BMI { get; set; }
        /// <summary>
        /// BMIScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("BMIScore")]
        public string BMIScore { get; set; }
        /// <summary>
        /// BMILevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("BMILevel")]
        public string BMILevel { get; set; }
        /// <summary>
        /// Pulmonary
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pulmonary")]
        public string Pulmonary { get; set; }
        /// <summary>
        /// PulmonaryScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("PulmonaryScore")]
        public string PulmonaryScore { get; set; }
        /// <summary>
        /// PulmonaryLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("PulmonaryLevel")]
        public string PulmonaryLevel { get; set; }
        /// <summary>
        /// FiftyRun
        /// </summary>
        /// <returns></returns>
        [DisplayName("FiftyRun")]
        public string FiftyRun { get; set; }
        /// <summary>
        /// FiftyRunScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("FiftyRunScore")]
        public string FiftyRunScore { get; set; }
        /// <summary>
        /// FiftyRunLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("FiftyRunLevel")]
        public string FiftyRunLevel { get; set; }
        /// <summary>
        /// StandJump
        /// </summary>
        /// <returns></returns>
        [DisplayName("StandJump")]
        public string StandJump { get; set; }
        /// <summary>
        /// StandJumpScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("StandJumpScore")]
        public string StandJumpScore { get; set; }
        /// <summary>
        /// StandJumpLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("StandJumpLevel")]
        public string StandJumpLevel { get; set; }
        /// <summary>
        /// SitAndReach
        /// </summary>
        /// <returns></returns>
        [DisplayName("SitAndReach")]
        public string SitAndReach { get; set; }
        /// <summary>
        /// SitAndReachScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("SitAndReachScore")]
        public string SitAndReachScore { get; set; }
        /// <summary>
        /// SitAndReachLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("SitAndReachLevel")]
        public string SitAndReachLevel { get; set; }
        /// <summary>
        /// EightHundred
        /// </summary>
        /// <returns></returns>
        [DisplayName("EightHundred")]
        public string EightHundred { get; set; }
        /// <summary>
        /// EightHundredScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("EightHundredScore")]
        public string EightHundredScore { get; set; }
        /// <summary>
        /// EightHundredLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("EightHundredLevel")]
        public string EightHundredLevel { get; set; }
        /// <summary>
        /// EightHundredAddScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("EightHundredAddScore")]
        public string EightHundredAddScore { get; set; }
        /// <summary>
        /// ThousandRun
        /// </summary>
        /// <returns></returns>
        [DisplayName("ThousandRun")]
        public string ThousandRun { get; set; }
        /// <summary>
        /// ThousandRunScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("ThousandRunScore")]
        public string ThousandRunScore { get; set; }
        /// <summary>
        /// ThousandRunLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("ThousandRunLevel")]
        public string ThousandRunLevel { get; set; }
        /// <summary>
        /// ThousandRunAddScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("ThousandRunAddScore")]
        public string ThousandRunAddScore { get; set; }
        /// <summary>
        /// MinSupination
        /// </summary>
        /// <returns></returns>
        [DisplayName("MinSupination")]
        public string MinSupination { get; set; }
        /// <summary>
        /// MinSupinationScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("MinSupinationScore")]
        public string MinSupinationScore { get; set; }
        /// <summary>
        /// MinSupinationLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("MinSupinationLevel")]
        public string MinSupinationLevel { get; set; }
        /// <summary>
        /// MinSupinationAddScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("MinSupinationAddScore")]
        public string MinSupinationAddScore { get; set; }
        /// <summary>
        /// PullUp
        /// </summary>
        /// <returns></returns>
        [DisplayName("PullUp")]
        public string PullUp { get; set; }
        /// <summary>
        /// PullUpScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("PullUpScore")]
        public string PullUpScore { get; set; }
        /// <summary>
        /// PullUpLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("PullUpLevel")]
        public string PullUpLevel { get; set; }
        /// <summary>
        /// PullUpAddScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("PullUpAddScore")]
        public string PullUpAddScore { get; set; }
        /// <summary>
        /// TestResult
        /// </summary>
        /// <returns></returns>
        [DisplayName("TestResult")]
        public string TestResult { get; set; }
        /// <summary>
        /// StudentTrueScore
        /// </summary>
        /// <returns></returns>
        [DisplayName("StudentTrueScore")]
        public string StudentTrueScore { get; set; }
        /// <summary>
        /// TestType
        /// </summary>
        /// <returns></returns>
        [DisplayName("TestType")]
        public string TestType { get; set; }
        /// <summary>
        /// CreateTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateTime")]
        public string CreateTime { get; set; }
        /// <summary>
        /// UpdateTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("UpdateTime")]
        public string UpdateTime { get; set; }
        /// <summary>
        /// Remark
        /// </summary>
        /// <returns></returns>
        [DisplayName("Remark")]
        public string Remark { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ID = KeyValue;
                                            }
        #endregion
    }
}