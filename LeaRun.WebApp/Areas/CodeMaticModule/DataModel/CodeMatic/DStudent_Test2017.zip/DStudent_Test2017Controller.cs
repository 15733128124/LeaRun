using LeaRun.Business;
using LeaRun.Entity;
using LeaRun.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// ѧ�����Ա�������ݽ�����������
    /// </summary>
    public class DStudent_Test2017Controller : PublicController<DStudent_Test2017>
    {
    }
}